How to start program:
Compile and run from StartingFrame.java

Credits (Images):
Bomb: https://ctl.s6img.com/society6/img/-XopFY89l6dyvWbLIhIPUVGGThM/w_700/prints/~artwork/s6-0050/a/21687459_4003988/~~/bomb-sprite-prints.jpg?wait=0&attempt=0
Meteor Gun: http://pixelartmaker.com/art/a11de2116e5fb67
Slow enemy: https://www.123rf.com/photo_82436997_stock-vector-snail-pixel-cartoon-retro-game-style-set.html
Players: https://phaser.io/content/tutorials/coding-tips-005/pacman.png 
Speed Boost: http://pixelartmaker.com/art/a9f00c9246bf3dd.png  https://transformice.fandom.com/wiki/Speed_Boost 
Fire: https://images.pond5.com/pixel-art-style-fire-4k-footage-088243748_prevstill.jpeg
Galaxy: https://images.wallpaperscraft.com/image/galaxy_stars_nebulae_clusters_68741_300x188.jpg  
Googly Eyes: https://www.stickpng.com/assets/images/5aafb1cc7603fc558cffc0c6.png 
Pac-Man: https://www.nintendo.com/content/dam/noa/en_US/games/switch/n/namco-museum-pac-man-vs-free-multiplayer-only-version-switch/Switch_NAMCOMUSEUM-PACMAN_description-char.png 

Credits (Code):
StartingFrame.Java and GameFrame.Java outlines are from Mr.Mangat's demo code
.setBounds: http://www.java2s.com/Code/Java/Swing-JFC/LayingOutComponentsUsingAbsoluteCoordinates.htm

Credits (Font):
Pac-Man Font:https://www.1001fonts.com/crackman-font.html#character-map-regular 